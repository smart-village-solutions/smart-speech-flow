# KasselDIALOG · Übergabe an die Gestaltung

Arbeitsfassung. Das gesondert bereitgestellte PDF zeigt die aktuelle Anordnung.
`kasseldialog-folientexte.docx` enthält die Texte aller 26 Folien, ohne eingebettete Bilder.
`screenshots/` enthält alle vorhandenen Originalaufnahmen; `grafiken/` enthält G02–G04 als SVG und Vektor-PDF.

## Bildzuordnung im aktuellen PDF

- Folie 01 · KasselDIALOG – Nutzerdokumentation: screenshots/S13a-Gespräch-Nutzer2.png
- Folie 02 · KasselDIALOG auf einen Blick: grafiken/G02.svg (auch als PDF)
- Folie 03 · Vor dem Gespräch: grafiken/G03.svg (auch als PDF)
- Folie 04 · Einladung erhalten und Passwort festlegen: screenshots/P00-Email.png, screenshots/P01-Passwort-ändern.png, screenshots/P02-Neues-Passwort.png
- Folie 05 · Anmelden: screenshots/P03-Login.png, screenshots/S01-Startseite.png, screenshots/S02-Organisationsauswahl.png
- Folie 06 · Gespräch eröffnen: screenshots/S03-Gesprächsübersicht-leer.png, screenshots/S04-Warnung.png
- Folie 07 · Einladung anzeigen: screenshots/S05-Gesprächscode.png
- Folie 08 · Einladung weitergeben und warten: screenshots/S05-Gesprächscode.png, screenshots/S06-Sprachwahl.png, screenshots/S07-Infoseite.png, screenshots/S08-Infoseite-ohne-Frage.png
- Folie 09 · Gesprächsansicht verstehen: screenshots/S13a-Gespräch-Nutzer2.png
- Folie 10 · Nachricht sprechen: screenshots/S10-Gespräch-Gast2.png, screenshots/S10-Gespräch-Gast3.png
- Folie 11 · Spracheingabe senden und Übersetzung lesen: screenshots/S10-Gespräch-Gast3.png, screenshots/S11-Gespräch-Nutzer1.png
- Folie 12 · Nachricht schreiben: screenshots/S12-Texteingabe.png
- Folie 13 · Übersetztes Gespräch sehen: screenshots/S13a-Gespräch-Nutzer2.png, screenshots/S13b-Gespräch-Gast.png
- Folie 14 · Übersetzte Nachricht anhören: screenshots/S11-Gespräch-Nutzer1.png
- Folie 15 · Unklarheiten klären: kein Bild
- Folie 16 · Gespräch beenden: screenshots/S15-Beenden.png
- Folie 17 · So unterstützt KI das Gespräch: grafiken/G04.svg (auch als PDF)
- Folie 18 · Grenzen der KI erkennen: kein Bild
- Folie 19 · Praxisfall Übersetzungsfehler: kein Bild
- Folie 20 · Bei Übersetzungsfehlern handeln: kein Bild
- Folie 21 · Datenschutz vor und im Gespräch: screenshots/S07-Infoseite.png, screenshots/S08-Infoseite-ohne-Frage.png
- Folie 22 · Datenverarbeitung und Rechte: kein Bild
- Folie 23 · Probleme lösen: kein Bild
- Folie 24 · Häufige Fragen: kein Bild
- Folie 25 · Feedback geben: screenshots/S16-Feedback-de.png
- Folie 26 · Hilfe und Dokumentstand: kein Bild

## Zusätzlich enthaltene Originalaufnahmen

- screenshots/S09-Gespräch-Gast1.png
- screenshots/S16-Feedback-en.png

## Vor Veröffentlichung prüfen

- Die auf S05 und S04 sichtbaren Sitzungscodes, Einladungslinks und QR-Ziele dürfen nicht mehr nutzbar sein.
- Produktversion, Datenschutzinformation und Wortlaut der Ansichten müssen fachlich freigegeben werden.
- S09 ist derzeit eine Gästeansicht. Das PDF verwendet für Folie 09 die Mitarbeitendenansicht S13a.
- G05 und G06 wurden als Bilder gestrichen; die zugehörigen Folientexte bleiben erhalten.
